import { User } from "../models/user.model.js";

export const renderLogin = (req, res) => {
  return res.render("login.ejs", {
    header: {
      title: "Login | SocialMedia",
      desc: "",
      css: [],
      js: []
    },
    body: {},
    footer: {
      js: []
    }
  });
};

export const renderRegister = (req, res) => {
  return res.render("register.ejs", {
    header: {
      title: "Register | SocialMedia",
      desc: "",
      css: [],
      js: []
    },
    body: {},
    footer: {
      js: []
    }
  });
};

export const renderdashboard = async (req, res) => {

  try {
    const user = await User.findById(req.user._id);

    res.render("dashboard.ejs", {

      header: {
        title: "Dashboard | SocialMedia"
      },

      body: {
           user
      },

      footer: {
        js: []
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json(errorResponse("Server error"));
  }
};
export const renderForgotPassword = (req, res) => {
 try{
  res.render("forgot-password.ejs", {

      header: {
        title: "Forgot Password | SocialMedia"
      },

      body: {

      },

      footer: {
        js: []
      }
    });
  }catch (err) {
    console.error(err);
    res.status(500).json(errorResponse("Server error"));
  } 
};
export const renderResetPassword = (req, res) => {
 try{
    const { token } = req.params
  res.render("reset-password.ejs", {

      header: {
        title: "Reset Password | SocialMedia"
      },

      body: {
          token
      },

      footer: {
        js: []
      }
    });
  }catch (err) {
    console.error(err);
    res.status(500).json(errorResponse("Server error"));
  } 
};

export const renderVerifyPage = async (req, res) => {
  try{
  const user = await User.findById(req.params.id);

  if (!user) return res.redirect("/register");

  if (user.verified) return res.redirect("/login");

  res.render("verify-otp.ejs",{

      header: {
        title: "Verify Email | SocialMedia"
      },

      body: {
          userId: user._id,
      },

      footer: {
        js: []
      }
    });
  }
  catch (err) {
    console.error(err);
    res.status(500).json(errorResponse("Server error"));
  } 
 };

