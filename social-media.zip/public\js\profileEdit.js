document.addEventListener("DOMContentLoaded", function () {
console.log("Profile Edit JS loaded");
    const coverInput = document.getElementById("coverInput");

    const profileInput = document.getElementById("profileInput");
    const coverPreview = document.getElementById("coverPreview");
    const profilePreview = document.getElementById("profilePreview");

    if (coverInput && coverPreview) {
        coverInput.addEventListener("change", function () {
            const file = this.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function (e) {
                coverPreview.style.backgroundImage = `url('${e.target.result}')`;
            };
            reader.readAsDataURL(file);
        });
    }

    if (profileInput && profilePreview) {
        profileInput.addEventListener("change", function () {
            const file = this.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function (e) {
                profilePreview.src = e.target.result;
            };
            reader.readAsDataURL(file);
        });
    }
     const form = document.getElementById("editProfileForm");
    if(!form) return;
    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formData = new FormData(form);
        try{
            const res = await fetch("/profile/update-profile", {
                method: "POST",
                body: formData
            });

            const data = await res.json();
            if(data.flag === 1){
                showToast(data.msg || "Profile updated successfully!", "success");
                window.location.href = `/profile/${data.data.username}`;
            }
            else{
                showAlert(data.message || "Profile update failed", "danger");
            }   
        }
        catch(error){
            showAlert("An error occurred while updating profile", "danger");
        }
});

});