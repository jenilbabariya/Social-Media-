import express from "express";
import authRoutes from "./auth.routes.js";
import pagesRoutes from "./pages.routes.js";

const router = express.Router();

router.use("/api/auth", authRoutes);
router.use("/", pagesRoutes);


export default router;