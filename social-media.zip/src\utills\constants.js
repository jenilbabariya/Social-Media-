export const UPLOAD_PATH = "uploads/";

export const ALLOWED_IMAGE_TYPES = [
  "image/jpeg",
  "image/png",
  "image/jpg",
];

export const MAX_FILE_SIZE = 2 * 1024 * 1024; 
