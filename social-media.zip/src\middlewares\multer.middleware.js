import multer from "multer";
import path from "path";
import fs from "fs";
import { UPLOAD_PATH, ALLOWED_IMAGE_TYPES, MAX_FILE_SIZE } from "../utills/constants.js";

const ensureDir = (dirPath) => {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    let uploadDir = "";

    if (file.fieldname === "profilePicture") {
      uploadDir = path.join(UPLOAD_PATH, "profile/profilePicture");
    } else if (file.fieldname === "coverPhoto") {
      uploadDir = path.join(UPLOAD_PATH, "profile/coverphoto");
    }

    ensureDir(uploadDir);
    cb(null, uploadDir);
  },

  filename: (req, file, cb) => {
    const uniqueName =
      Date.now() + "-" + Math.round(Math.random() * 1e9);

    cb(null, uniqueName + path.extname(file.originalname));
  },
});

const fileFilter = (req, file, cb) => {
  if (ALLOWED_IMAGE_TYPES.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error("Only image files are allowed"), false);
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: MAX_FILE_SIZE },
});

export default upload;
