import app from "./app.js";
import env from "./src/config/env.js"

import connectDB from "./src/config/db.js";

await connectDB();

const server = app.listen(env.port, ()=>{
    console.log(`server is running on ${env.port}`);
});