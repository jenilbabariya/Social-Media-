document.addEventListener("DOMContentLoaded", () => {
    const followBtn = document.getElementById("followBtn");
    const statsDiv = document.querySelector(".profile-stats");
    const profileIsPrivate = statsDiv?.dataset.private === "true";
    const profileUserId = statsDiv?.dataset.userid;

    if (!followBtn) return;

    followBtn.addEventListener("click", async () => {
        const userId = followBtn.dataset.id;
        const isFollowing = followBtn.dataset.following === "true";

        try {

   
            if (!isFollowing) {

                const res = await fetch(`/profile/follow/${userId}`, {
                    method: "POST",
                    credentials: "same-origin",
                    headers: { "Content-Type": "application/json" }
                });

                const data = await res.json();

                if (data.flag !== 1) {
                    return showToast(data.msg || "Failed to follow", "danger");
                }

                if (profileIsPrivate) {
                    followBtn.textContent = "Requested";
                    followBtn.dataset.following = "false";

                    statsDiv.innerHTML = `
                        <div class="stat-item">
                            <strong>${data.data.followersCount}</strong>
                            <span>Followers</span>
                        </div>
                        <div class="stat-item">
                            <strong>${data.data.followingCount}</strong>
                            <span>Following</span>
                        </div>
                    `;
                } else {
                    followBtn.textContent = "Unfollow";
                    followBtn.dataset.following = "true";

                    statsDiv.innerHTML = `
                        <a href="/profile/${profileUserId}/connections?type=followers" class="stat-item">
                            <strong>${data.data.followersCount}</strong>
                            <span>Followers</span>
                        </a>
                        <a href="/profile/${profileUserId}/connections?type=following" class="stat-item">
                            <strong>${data.data.followingCount}</strong>
                            <span>Following</span>
                        </a>
                    `;
                }

                showToast(data.msg || "Success!", "success");
            }

        
            else {

                const res = await fetch(`/profile/unfollow/${userId}`, {
                    method: "DELETE",
                    credentials: "same-origin",
                    headers: { "Content-Type": "application/json" }
                });

                const data = await res.json();

                if (data.flag !== 1) {
                    return showToast(data.msg || "Failed to unfollow", "danger");
                }

                followBtn.textContent = "Follow";
                followBtn.dataset.following = "false";

                if (profileIsPrivate) {
                    statsDiv.innerHTML = `
                        <div class="stat-item">
                            <strong>${data.data.followersCount}</strong>
                            <span>Followers</span>
                        </div>
                        <div class="stat-item">
                            <strong>${data.data.followingCount}</strong>
                            <span>Following</span>
                        </div>
                    `;
                } else {
                    statsDiv.innerHTML = `
                        <a href="/profile/${profileUserId}/connections?type=followers" class="stat-item">
                            <strong>${data.data.followersCount}</strong>
                            <span>Followers</span>
                        </a>
                        <a href="/profile/${profileUserId}/connections?type=following" class="stat-item">
                            <strong>${data.data.followingCount}</strong>
                            <span>Following</span>
                        </a>
                    `;
                }

                showToast(data.msg || "Unfollowed!", "success");
            }

        } catch (error) {
            console.error("Error:", error);
            showToast("An error occurred. Please try again.", "danger");
        }
    });
});